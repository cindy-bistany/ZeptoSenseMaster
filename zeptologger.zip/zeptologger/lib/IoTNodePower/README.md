About
===

Library that uses the I2C bus and Microchip MCP23017 IO expander to control and monitor the power setting of the IoT Node circuitry.
Version 2 has an error.
Version 3 added digitalWrite
Version 4 added setPullUp
