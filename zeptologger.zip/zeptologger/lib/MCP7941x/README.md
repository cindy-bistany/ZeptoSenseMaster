About
===

Real Time Clock library for the Microchip MCP7941x. Based on work by Ian Chilton.
